/* ==========================================================================
   LOCAGABON AI - LOGIQUE APPLICATIVE (LOCATIONS, VENTES, PARTICULIERS & AGENCES PRO)
   ========================================================================== */

const EUR_CONVERSION_RATE = 655.957; // Taux de parité fixe FCFA (XAF) / EURO (€)
const COMMISSION_RATE = 0.03; // 3% de commission LocaGabon

// --- BASE DE DONNÉES ENRICHIE (LOCATIONS & VENTES / PARTICULIERS & AGENCES) ---
const INITIAL_PROPERTIES = [
  {
    id: "prop-1",
    title: "Appartement 3 Pièces Spacieux - Angondjé Château",
    city: "Akanda (Angondjé)",
    type: "Appartement",
    operation: "Location",
    sellerType: "Agence Pro",
    price: 250000,
    cautionMois: 2,
    edan: true,
    seeg: true,
    gardien: true,
    clim: true,
    titreFoncier: false,
    image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=600&q=80",
    description: "Bel appartement géré par Agence Pro comprenant grand séjour, 2 chambres, 2 salles de bain, cuisine équipée. Compteur EDAN individuel et eau SEEG sans coupure.",
    verified: true,
    bailleur: "Agence Immo Gabon Pro SA (NIF: 2026-B-89192)"
  },
  {
    id: "prop-2",
    title: "Studio Moderne Haut Standing - Quartier Louis",
    city: "Libreville (Centre)",
    type: "Studio",
    operation: "Location",
    sellerType: "Particulier",
    price: 180000,
    cautionMois: 2,
    edan: true,
    seeg: true,
    gardien: true,
    clim: true,
    titreFoncier: false,
    image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=600&q=80",
    description: "Studio en direct propriétaire (Sans frais d'agence) à Louis, proche bord de mer. Sécurité 24h/24, gardien, parking et surpresseur SEEG.",
    verified: true,
    bailleur: "Mme NTOUTOUME Carine (Particulier)"
  },
  {
    id: "prop-3",
    title: "Terrain 1 000 m² à Vendre avec Titre Foncier - Avorbam",
    city: "Akanda (Angondjé)",
    type: "Terrain",
    operation: "Vente",
    sellerType: "Agence Pro",
    price: 35000000,
    cautionMois: 0,
    edan: true,
    seeg: true,
    gardien: false,
    clim: false,
    titreFoncier: true,
    image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=600&q=80",
    description: "Magnifique parcelle plate de 1 000 m² idéale pour construction de villa. Titre Foncier définitif et vérifié. Vendu par Agence Immobilière agréée.",
    verified: true,
    bailleur: "Agence Cabinet Foncier Gabon"
  },
  {
    id: "prop-4",
    title: "Villa Duplex 4 Chambres à Vendre - Batterie IV",
    city: "Batterie IV",
    type: "Villa",
    operation: "Vente",
    sellerType: "Particulier",
    price: 180000000,
    cautionMois: 0,
    edan: true,
    seeg: true,
    gardien: true,
    clim: true,
    titreFoncier: true,
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=600&q=80",
    description: "Villa d'architecte en vente directe propriétaire à Batterie IV. Jardin arboré, piscine, groupe électrogène et réserve d'eau. Titre Foncier disponible.",
    verified: true,
    bailleur: "M. ONDO Jean-Marc (Particulier)"
  },
  {
    id: "prop-5",
    title: "Chambre Confort Clôturée - Owendo Cité Octra",
    city: "Owendo",
    type: "Chambre",
    operation: "Location",
    sellerType: "Particulier",
    price: 90000,
    cautionMois: 2,
    edan: true,
    seeg: true,
    gardien: false,
    clim: false,
    titreFoncier: false,
    image: "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=600&q=80",
    description: "Chambre autonome louée directement par le propriétaire. Cuisine américaine et compteur EDAN indépendant.",
    verified: true,
    bailleur: "M. ONDO Paul (Particulier)"
  },
  {
    id: "prop-6",
    title: "Appartement 2 Pièces Rénové - Port-Gentil Ntchoréré",
    city: "Port-Gentil",
    type: "Appartement",
    operation: "Location",
    sellerType: "Agence Pro",
    price: 220000,
    cautionMois: 2,
    edan: true,
    seeg: true,
    gardien: true,
    clim: true,
    titreFoncier: false,
    image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=600&q=80",
    description: "Appartement sous mandat d'agence à Port-Gentil. Climatisation, sécurité et environnement calme.",
    verified: true,
    bailleur: "Agence Ogooué Immobilier Pro"
  }
];

let BAILLEUR_TENANTS = [
  { id: "t1", bien: "Appartement 3P Angondjé", quartier: "Akanda", locataire: "KASSA Marc", loyer: "250 000 FCFA", statut: "Payé (Airtel Money)" },
  { id: "t2", bien: "Studio Moderne Louis", quartier: "Louis", locataire: "ESSONO Alain", loyer: "180 000 FCFA", statut: "Payé (Moov Money)" },
  { id: "t3", bien: "Terrain 1 000 m² Avorbam", quartier: "Akanda", locataire: "Compromis de Vente", loyer: "35 000 000 FCFA", statut: "En cours" }
];

let TENANT_RECEIPTS = [
  { id: "GAB-2026-771", mois: "Juillet 2026", montant: "250 000 FCFA", methode: "Airtel Money (*150#)", date: "03/07/2026" },
  { id: "GAB-2026-642", mois: "Juin 2026", montant: "250 000 FCFA", methode: "Moov Money (*555#)", date: "02/06/2026" }
];

let ADMIN_TRANSACTIONS = [
  { id: "TX-99120", bien: "Appartement 3P - Akanda", sellerType: "Agence Pro", brut: 250000, comm: 7500, canal: "Airtel Money Gabon", date: "01/08/2026" },
  { id: "TX-99104", bien: "Studio Haut Standing - Louis", sellerType: "Particulier", brut: 180000, comm: 5400, canal: "Moov Money (*555#)", date: "30/07/2026" },
  { id: "TX-98942", bien: "Villa Duplex - Batterie IV (Vente)", sellerType: "Agence Pro", brut: 180000000, comm: 5400000, canal: "Virement Bancaire (BGFI)", date: "28/07/2026" }
];

let adminFinancials = {
  totalVolumeFCFA: 181030000,
  commissionFCFA: 5430900,
  revolutBalanceEUR: 8279.35
};

let state = {
  properties: [...INITIAL_PROPERTIES],
  currentSection: "section-annonces",
  activePropertyForPay: INITIAL_PROPERTIES[0],
  currentUser: null
};

// --- INITIALISATION ---
document.addEventListener("DOMContentLoaded", () => {
  renderProperties(state.properties);
  renderBailleurTable();
  renderTenantReceipts();
  renderAdminDashboard();
  initDashboardCharts();
  setupNavigation();
  setupSearchTabs();
  setupAISearch();
  setupClassicFilters();
  setupIAChat();
  setupModals();
  setupAuthModal();
  setupPaymentSystem();
  setupAdminRevolutPayout();
  setupPricingAndContact();
});

// --- NAVIGATION ---
function setupNavigation() {
  const navBtns = document.querySelectorAll(".nav-btn");
  const sections = document.querySelectorAll(".app-section");

  navBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-target");
      if (!targetId) return;

      navBtns.forEach(b => b.classList.remove("active"));
      sections.forEach(s => s.classList.remove("active"));

      btn.classList.add("active");
      const targetSection = document.getElementById(targetId);
      if (targetSection) {
        targetSection.classList.add("active");
        window.scrollTo({ top: targetSection.offsetTop - 80, behavior: "smooth" });
      }
    });
  });

  document.getElementById("logoBtn")?.addEventListener("click", () => {
    document.querySelector('.nav-btn[data-target="section-annonces"]')?.click();
  });
}

// --- AUTH MODAL (LOCATAIRE, BAILLEUR PARTICULIER OU AGENCE PRO) ---
function setupAuthModal() {
  const btnOpen = document.getElementById("btnOpenAuthModal");
  const modal = document.getElementById("authModal");
  const btnClose = document.getElementById("closeAuthModal");
  const tabLogin = document.getElementById("tabAuthLogin");
  const tabRegister = document.getElementById("tabAuthRegister");
  const formLogin = document.getElementById("formLogin");
  const formRegister = document.getElementById("formRegister");
  const roleSelect = document.getElementById("userRoleSelect");
  const groupNif = document.getElementById("groupAgencyNif");
  const lblName = document.getElementById("lblRegisterName");

  if (!modal) return;

  btnOpen?.addEventListener("click", () => openModal("authModal"));
  btnClose?.addEventListener("click", () => closeModal("authModal"));

  tabLogin?.addEventListener("click", () => {
    tabLogin.classList.add("active");
    tabRegister.classList.remove("active");
    formLogin.classList.remove("hidden");
    formRegister.classList.add("hidden");
  });

  tabRegister?.addEventListener("click", () => {
    tabRegister.classList.add("active");
    tabLogin.classList.remove("active");
    formRegister.classList.remove("hidden");
    formLogin.classList.add("hidden");
  });

  // Changement dynamique du formulaire si Agence Pro est sélectionnée
  roleSelect?.addEventListener("change", (e) => {
    const val = e.target.value;
    if (val === "agence") {
      groupNif.style.display = "block";
      lblName.textContent = "Nom officiel de l'Agence Immobilière / Société";
    } else {
      groupNif.style.display = "none";
      lblName.textContent = "Nom complet";
    }
  });

  formLogin?.addEventListener("submit", (e) => {
    e.preventDefault();
    closeModal("authModal");
    state.currentUser = { name: "Utilisateur Connecté" };
    if (btnOpen) btnOpen.innerHTML = `<i class="ri-user-check-fill" style="color: var(--accent-emerald);"></i> Mon Compte`;
    alert("Bienvenue ! Vous êtes désormais connecté à votre espace LocaGabon.");
  });

  formRegister?.addEventListener("submit", (e) => {
    e.preventDefault();
    const role = roleSelect.value;
    const name = document.getElementById("regNameInput").value;
    closeModal("authModal");
    state.currentUser = { name, role };
    let roleTxt = "Locataire / Acheteur";
    if (role === "particulier") roleTxt = "Bailleur Particulier";
    if (role === "agence") roleTxt = "Bailleur Professionnel (Agence Pro)";
    
    if (btnOpen) btnOpen.innerHTML = `<i class="ri-user-check-fill" style="color: var(--accent-emerald);"></i> ${name} (${roleTxt})`;
    alert(`Votre compte "${roleTxt}" pour "${name}" a été créé avec succès !`);
  });
}

// --- ABONNEMENTS ET CONTACT ---
function setupPricingAndContact() {
  const planBtns = document.querySelectorAll(".btn-select-plan");
  const supportBtn = document.getElementById("btnOpenSupportChat");

  planBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const planName = btn.getAttribute("data-plan");
      if (planName.includes("Gratuit")) {
        alert("Vous utilisez actuellement la Formule Découverte gratuite !");
      } else {
        let price = 2500;
        if (planName.includes("15 000")) price = 15000;
        if (planName.includes("35 000")) price = 35000;

        openPaymentModal({
          title: `Souscription : ${planName}`,
          price,
          bailleur: "LocaGabon Services"
        });
      }
    });
  });

  supportBtn?.addEventListener("click", () => {
    document.querySelector('.nav-btn[data-target="section-ia-juridique"]')?.click();
  });
}

// --- RENDER ANNONCES (LOCATION / VENTE - PARTICULIER / AGENCE PRO) ---
function renderProperties(props) {
  const grid = document.getElementById("propertyGrid");
  const countEl = document.getElementById("resultsCount");
  if (!grid) return;
  countEl.textContent = `${props.length} annonce(s) trouvée(s)`;

  if (props.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 3rem; background: var(--bg-surface); border-radius: var(--radius-lg);">
        <i class="ri-search-eye-line" style="font-size: 3rem; color: var(--accent-gold);"></i>
        <h3 style="margin-top: 1rem;">Aucun bien ne correspond à votre recherche</h3>
        <p style="color: var(--text-secondary);">Essayez de modifier vos filtres (Vente/Location ou Agence/Particulier).</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = props.map(p => {
    const isSale = p.operation === "Vente";
    const isAgency = p.sellerType === "Agence Pro";

    return `
      <div class="property-card">
        <div class="prop-img-wrapper">
          <img src="${p.image}" alt="${p.title}" loading="lazy">
          
          <!-- Badge Agence Pro vs Particulier -->
          ${isAgency ? 
            `<span class="badge-seller-pro"><i class="ri-building-2-fill"></i> Agence Pro</span>` : 
            `<span class="badge-seller-private"><i class="ri-user-user-line"></i> Particulier</span>`
          }

          <!-- Badge Location vs Vente -->
          <span class="badge-op-type ${isSale ? 'badge-op-sale' : 'badge-op-rent'}">${p.operation}</span>

          <!-- Prix -->
          <span class="prop-badge-price">${p.price.toLocaleString('fr-FR')} FCFA${isSale ? '' : '<small>/mois</small>'}</span>
        </div>

        <div class="prop-content">
          <h3 class="prop-title">${p.title}</h3>
          <div class="prop-location">
            <i class="ri-map-pin-2-fill"></i> ${p.city} | Par : <strong>${p.bailleur}</strong>
          </div>

          <div class="prop-tags">
            ${isSale ? 
              (p.titreFoncier ? `<span class="tag-item highlight"><i class="ri-file-shield-2-line"></i> Titre Foncier Valide</span>` : `<span class="tag-item"><i class="ri-landscape-line"></i> En cours de Titre</span>`) : 
              `<span class="tag-item highlight"><i class="ri-shield-keyhole-line"></i> Caution : ${p.cautionMois} mois légal</span>`
            }
            ${p.edan ? `<span class="tag-item"><i class="ri-flashlight-line"></i> Compteur EDAN</span>` : ''}
            ${p.seeg ? `<span class="tag-item"><i class="ri-drop-line"></i> Eau SEEG</span>` : ''}
            ${p.gardien ? `<span class="tag-item"><i class="ri-user-protect-line"></i> Gardien</span>` : ''}
          </div>

          <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 1rem; flex: 1;">
            ${p.description}
          </p>

          <div class="prop-footer">
            <button class="btn-card-primary btn-pay-prop" data-id="${p.id}">
              <i class="${isSale ? 'ri-hand-coin-line' : 'ri-smartphone-line'}"></i> ${isSale ? 'Réserver / Acheter' : 'Réserver / Louer'}
            </button>
            <button class="btn-card-secondary btn-ask-ia" data-title="${p.title}" data-bailleur="${p.bailleur}">
              <i class="ri-robot-line"></i> Info IA
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  document.querySelectorAll(".btn-pay-prop").forEach(btn => {
    btn.addEventListener("click", () => {
      const propId = btn.getAttribute("data-id");
      const targetProp = state.properties.find(p => p.id === propId);
      if (targetProp) {
        openPaymentModal(targetProp);
      }
    });
  });

  document.querySelectorAll(".btn-ask-ia").forEach(btn => {
    btn.addEventListener("click", () => {
      const title = btn.getAttribute("data-title");
      const bailleur = btn.getAttribute("data-bailleur");
      document.querySelector('.nav-btn[data-target="section-ia-juridique"]')?.click();
      const prompt = `Je suis intéressé par l'offre "${title}" proposée par ${bailleur}. Quels sont les éléments légaux et documents obligatoires au Gabon ?`;
      sendIAMessage(prompt);
    });
  });
}

// --- RECHERCHE PAR INTELLIGENCE ARTIFICIELLE ---
function setupSearchTabs() {
  const tabAI = document.getElementById("tabSmartAI");
  const tabFilter = document.getElementById("tabClassicFilter");
  const aiBox = document.getElementById("aiSearchContainer");
  const classicBox = document.getElementById("classicFilterContainer");

  if (!tabAI || !tabFilter) return;

  tabAI.addEventListener("click", () => {
    tabAI.classList.add("active");
    tabFilter.classList.remove("active");
    aiBox.classList.remove("hidden");
    classicBox.classList.add("hidden");
  });

  tabFilter.addEventListener("click", () => {
    tabFilter.classList.add("active");
    tabAI.classList.remove("active");
    classicBox.classList.remove("hidden");
    aiBox.classList.add("hidden");
  });
}

function setupAISearch() {
  const input = document.getElementById("aiSearchInput");
  const btn = document.getElementById("btnRunAISearch");
  const chips = document.querySelectorAll(".sug-chip");

  if (!input || !btn) return;

  const executeAISearch = (queryText) => {
    if (!queryText.trim()) return;

    const queryLower = queryText.toLowerCase();

    const filtered = INITIAL_PROPERTIES.filter(p => {
      let matches = false;
      
      if (queryLower.includes("vente") || queryLower.includes("acheter") || queryLower.includes("achat") || queryLower.includes("terrain")) {
        if (p.operation === "Vente") matches = true;
      }
      if (queryLower.includes("location") || queryLower.includes("louer")) {
        if (p.operation === "Location") matches = true;
      }
      if (queryLower.includes("agence") || queryLower.includes("pro")) {
        if (p.sellerType === "Agence Pro") matches = true;
      }
      if (queryLower.includes("particulier") || queryLower.includes("direct")) {
        if (p.sellerType === "Particulier") matches = true;
      }

      if (queryLower.includes("akanda") || queryLower.includes("angondje")) {
        if (p.city.toLowerCase().includes("akanda")) matches = true;
      }
      if (queryLower.includes("louis") || queryLower.includes("centre") || queryLower.includes("libreville")) {
        if (p.city.toLowerCase().includes("libreville") || p.city.toLowerCase().includes("centre")) matches = true;
      }

      if (!matches && (p.title.toLowerCase().includes(queryLower) || p.description.toLowerCase().includes(queryLower))) {
        matches = true;
      }

      return matches;
    });

    renderProperties(filtered.length > 0 ? filtered : INITIAL_PROPERTIES);
  };

  btn.addEventListener("click", () => executeAISearch(input.value));
  input.addEventListener("keypress", (e) => {
    if (e.key === "Enter") executeAISearch(input.value);
  });

  chips.forEach(chip => {
    chip.addEventListener("click", () => {
      const q = chip.getAttribute("data-query");
      input.value = q;
      executeAISearch(q);
    });
  });
}

function setupClassicFilters() {
  const btn = document.getElementById("btnApplyClassicFilter");
  if (!btn) return;
  btn.addEventListener("click", () => {
    const op = document.getElementById("filterOperation").value;
    const seller = document.getElementById("filterSellerType").value;
    const city = document.getElementById("filterCity").value;
    const type = document.getElementById("filterType").value;

    const filtered = INITIAL_PROPERTIES.filter(p => {
      if (op !== "all" && p.operation !== op) return false;
      if (seller !== "all" && p.sellerType !== seller) return false;
      if (city !== "all" && !p.city.includes(city.split(" ")[0])) return false;
      if (type !== "all" && p.type !== type) return false;
      return true;
    });

    renderProperties(filtered);
  });
}

// --- MOTEUR D'ASSISTANT IA JURIDIQUE ---
function setupIAChat() {
  const btnSend = document.getElementById("btnSendChatMessage");
  const input = document.getElementById("chatInput");
  const presets = document.querySelectorAll(".btn-preset-ia");

  if (!btnSend || !input) return;

  btnSend.addEventListener("click", () => {
    const txt = input.value.trim();
    if (txt) {
      sendIAMessage(txt);
      input.value = "";
    }
  });

  input.addEventListener("keypress", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      const txt = input.value.trim();
      if (txt) {
        sendIAMessage(txt);
        input.value = "";
      }
    }
  });

  presets.forEach(btn => {
    btn.addEventListener("click", () => {
      const prompt = btn.getAttribute("data-prompt");
      sendIAMessage(prompt);
    });
  });
}

function sendIAMessage(userQuery) {
  const chatMessages = document.getElementById("chatMessages");
  if (!chatMessages) return;

  const userDiv = document.createElement("div");
  userDiv.className = "message msg-user";
  userDiv.innerHTML = `
    <div class="msg-avatar"><i class="ri-user-fill"></i></div>
    <div class="msg-content"><p>${escapeHtml(userQuery)}</p></div>
  `;
  chatMessages.appendChild(userDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  const aiThinkingDiv = document.createElement("div");
  aiThinkingDiv.className = "message msg-ai";
  aiThinkingDiv.innerHTML = `
    <div class="msg-avatar"><i class="ri-robot-2-fill"></i></div>
    <div class="msg-content"><p><em><i class="ri-loader-4-line spin"></i> Analyse du droit immobilier gabonais (Location/Vente)...</em></p></div>
  `;
  chatMessages.appendChild(aiThinkingDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  setTimeout(() => {
    const aiResponseHTML = generateAIResponse(userQuery);
    aiThinkingDiv.querySelector(".msg-content").innerHTML = aiResponseHTML;
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }, 900);
}

function generateAIResponse(query) {
  const q = query.toLowerCase();

  if (q.includes("caution") || q.includes("dépôt de garantie")) {
    return `
      <p><strong><i class="ri-scales-fill"></i> Réglementation du Dépôt de Garantie au Gabon :</strong></p>
      <p>Selon la législation gabonaise régissant les baux d'habitation :</p>
      <ul>
        <li>La caution est <strong>strictement plafonnée entre 2 et 3 mois de loyer principal maximum</strong>.</li>
        <li>Restitution obligatoire dans les 30 jours suivant la remise des clés et l'état des lieux.</li>
      </ul>
    `;
  }

  if (q.includes("vente") || q.includes("titre foncier") || q.includes("achat")) {
    return `
      <p><strong><i class="ri-file-shield-fill"></i> Législation des Ventes Immobilières au Gabon :</strong></p>
      <ul>
        <li><strong>Titre Foncier Obligatoire :</strong> Toute vente de terrain ou villa au Gabon doit faire l'objet d'un Titre Foncier vérifié auprès de la Conservation Foncière.</li>
        <li><strong>Rôle des Agences Pro :</strong> Les agences immatriculées au RCCM avec NIF garantissent la validité juridique du mandat de vente.</li>
      </ul>
    `;
  }

  return `
    <p><strong><i class="ri-shield-flash-line"></i> Recommandation de l'Assistant IA LocaGabon :</strong></p>
    <p>Pour vos transactions (Locations & Ventes au Gabon) :</p>
    <ul>
      <li>Exigez des quittances ou reçus officiels via <strong>Airtel Money</strong> ou <strong>Moov Money</strong>.</li>
      <li>Vérifiez toujours le badge <strong>Agence Pro Certifiée</strong> ou la pièce d'identité du Particulier.</li>
    </ul>
  `;
}

// --- PAIEMENT DIGITAL ---
function setupPaymentSystem() {
  const btnConfirm = document.getElementById("btnConfirmPayment");
  const radioMethods = document.querySelectorAll('input[name="payMethod"]');

  if (!btnConfirm) return;

  radioMethods.forEach(radio => {
    radio.addEventListener("change", (e) => {
      document.querySelectorAll(".pay-method-card").forEach(c => c.classList.remove("active"));
      e.target.closest(".pay-method-card").classList.add("active");
    });
  });

  btnConfirm.addEventListener("click", () => {
    const phone = document.getElementById("payPhoneNumber").value.trim();
    const selectedMethod = document.querySelector('input[name="payMethod"]:checked').value;

    if ((selectedMethod === "airtel" || selectedMethod === "moov") && !phone) {
      alert("Veuillez saisir votre numéro de téléphone Mobile Money Gabon.");
      return;
    }

    btnConfirm.disabled = true;
    btnConfirm.innerHTML = `<i class="ri-loader-4-line spin"></i> Traitement de la transaction...`;

    setTimeout(() => {
      btnConfirm.disabled = false;
      btnConfirm.innerHTML = `<i class="ri-lock-password-line"></i> Valider et Payer Maintenant`;

      let methodName = "Airtel Money Gabon (*150#)";
      if (selectedMethod === "moov") methodName = "Moov Money (*555#)";
      if (selectedMethod === "card") methodName = "Carte Bancaire Visa/Mastercard";
      if (selectedMethod === "transfer") methodName = "Virement Bancaire BGFI/UGB";

      const receiptId = `GAB-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const currentProp = state.activePropertyForPay;
      const brutAmount = currentProp.price;
      const commAmount = Math.round(brutAmount * COMMISSION_RATE);

      TENANT_RECEIPTS.unshift({
        id: receiptId,
        mois: "Août 2026",
        montant: `${brutAmount.toLocaleString('fr-FR')} FCFA`,
        methode: methodName,
        date: new Date().toLocaleDateString('fr-FR')
      });
      renderTenantReceipts();

      adminFinancials.totalVolumeFCFA += brutAmount;
      adminFinancials.commissionFCFA += commAmount;

      ADMIN_TRANSACTIONS.unshift({
        id: `TX-${Math.floor(10000 + Math.random() * 90000)}`,
        bien: currentProp.title,
        sellerType: currentProp.sellerType,
        brut: brutAmount,
        comm: commAmount,
        canal: methodName.split(" ")[0] + " Money",
        date: new Date().toLocaleDateString('fr-FR')
      });

      renderAdminDashboard();

      closeModal("paymentModal");
      openReceiptModal(receiptId, "Mme/M. KASSA Marc", currentProp.bailleur, currentProp.title, `${brutAmount.toLocaleString('fr-FR')} FCFA`, methodName);
    }, 1200);
  });
}

function openPaymentModal(property) {
  state.activePropertyForPay = property;
  const payVal = document.getElementById("payAmountVal");
  if (payVal) payVal.textContent = `${property.price.toLocaleString('fr-FR')} FCFA`;
  openModal("paymentModal");
}

function openReceiptModal(id, tenant, landlord, address, amount, method) {
  document.getElementById("recIdVal").textContent = id;
  document.getElementById("recTenantName").textContent = tenant;
  document.getElementById("recLandlordName").textContent = landlord;
  document.getElementById("recAddress").textContent = address;
  document.getElementById("recAmount").textContent = amount;
  document.getElementById("recMethod").textContent = `Payé via ${method}`;
  openModal("receiptModal");
}

// --- GRAPHIQUES ADMIN ---
function initDashboardCharts() {
  if (typeof Chart === 'undefined') return;

  const ctxGrowth = document.getElementById('growthChart')?.getContext('2d');
  if (ctxGrowth) {
    new Chart(ctxGrowth, {
      type: 'line',
      data: {
        labels: ['Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août 2026'],
        datasets: [
          {
            label: 'Locataires / Acheteurs',
            data: [320, 510, 740, 920, 1100, 1250],
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            fill: true,
            tension: 0.3
          },
          {
            label: 'Agences Pro & Bailleurs',
            data: [25, 48, 72, 98, 122, 148],
            borderColor: '#f59e0b',
            backgroundColor: 'transparent',
            tension: 0.3
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: '#94a3b8' } } },
        scales: {
          x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } },
          y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } }
        }
      }
    });
  }
}

// --- ADMIN & REVOLUT ---
function renderAdminDashboard() {
  const volEl = document.getElementById("adminTotalVolume");
  const commFcfaEl = document.getElementById("adminCommissionFCFA");
  const commEurEl = document.getElementById("adminCommissionEUR");
  const revBalEl = document.getElementById("adminRevolutBalance");

  if (volEl) volEl.textContent = `${adminFinancials.totalVolumeFCFA.toLocaleString('fr-FR')} FCFA`;
  if (commFcfaEl) commFcfaEl.textContent = `${adminFinancials.commissionFCFA.toLocaleString('fr-FR')} FCFA`;
  
  const eurEquiv = (adminFinancials.commissionFCFA / EUR_CONVERSION_RATE).toFixed(2);
  if (commEurEl) commEurEl.textContent = `≈ ${parseFloat(eurEquiv).toLocaleString('fr-FR')} € (Taux fixe : 1 € = 655,957 FCFA)`;

  if (revBalEl) revBalEl.textContent = `${adminFinancials.revolutBalanceEUR.toLocaleString('fr-FR')} €`;

  const tbody = document.getElementById("adminTransactionsTable");
  if (tbody) {
    tbody.innerHTML = ADMIN_TRANSACTIONS.map(tx => `
      <tr>
        <td><strong>${tx.id}</strong></td>
        <td>${tx.bien}</td>
        <td>
          ${tx.sellerType === "Agence Pro"
            ? `<span class="badge-type-professionnel"><i class="ri-building-4-line"></i> Professionnel</span>`
            : `<span class="badge-type-particulier"><i class="ri-user-line"></i> Particulier</span>`}
        </td>
        <td>${tx.brut.toLocaleString('fr-FR')} FCFA</td>
        <td><strong style="color: var(--accent-emerald);">+${tx.comm.toLocaleString('fr-FR')} FCFA</strong></td>
        <td>${tx.canal}</td>
        <td><span class="badge-paid"><i class="ri-check-line"></i> Reversé</span></td>
      </tr>
    `).join('');
  }
}

function setupAdminRevolutPayout() {
  const inputFCFA = document.getElementById("payoutAmountFCFA");
  const inputEUR = document.getElementById("payoutAmountEUR");
  const btnPayout = document.getElementById("btnTriggerRevolutTransfer");

  if (!inputFCFA || !btnPayout) return;

  inputFCFA.addEventListener("input", () => {
    const fcfaVal = parseFloat(inputFCFA.value) || 0;
    const eurVal = (fcfaVal / EUR_CONVERSION_RATE).toFixed(2);
    inputEUR.value = `${parseFloat(eurVal).toLocaleString('fr-FR')} €`;
  });

  btnPayout.addEventListener("click", () => {
    const fcfaToTransfer = parseFloat(inputFCFA.value) || 0;
    const iban = document.getElementById("payoutRevolutIBAN").value.trim();

    if (fcfaToTransfer <= 0 || fcfaToTransfer > adminFinancials.commissionFCFA) {
      alert("Montant invalide.");
      return;
    }

    const eurConverted = (fcfaToTransfer / EUR_CONVERSION_RATE).toFixed(2);
    adminFinancials.commissionFCFA -= fcfaToTransfer;
    adminFinancials.revolutBalanceEUR += parseFloat(eurConverted);

    renderAdminDashboard();
    alert(`✅ VIREMENT SEPA DE +${parseFloat(eurConverted).toLocaleString('fr-FR')} € ENVOYÉ AVEC SUCCÈS VERS REVOLUT (${iban}) !`);
  });
}

function renderBailleurTable() {
  const tbody = document.getElementById("bailleurTableBody");
  if (!tbody) return;

  tbody.innerHTML = BAILLEUR_TENANTS.map(t => `
    <tr>
      <td><strong>${t.bien}</strong></td>
      <td>${t.quartier}</td>
      <td>${t.locataire}</td>
      <td>${t.loyer}</td>
      <td>
        <span class="${t.statut.includes('Payé') ? 'badge-paid' : 'badge-pending'}">
          ${t.statut}
        </span>
      </td>
      <td>
        <button class="btn-card-secondary" onclick="alert('Notification envoyée pour ${t.locataire}')" style="padding: 0.3rem 0.6rem; font-size: 0.78rem;">
          <i class="ri-notification-3-line"></i> Notifier
        </button>
      </td>
    </tr>
  `).join('');
}

function renderTenantReceipts() {
  const list = document.getElementById("receiptHistoryList");
  if (!list) return;

  list.innerHTML = TENANT_RECEIPTS.map(r => `
    <li class="history-item">
      <div class="history-item-info">
        <h5>Quittance ${r.mois} (${r.montant})</h5>
        <span>ID: ${r.id} | ${r.methode} le ${r.date}</span>
      </div>
      <button class="btn-card-secondary" onclick="openReceiptModal('${r.id}', 'Mme/M. KASSA Marc', 'M. MBOUMBA Jean-Pierre', 'Appartement 3P - Akanda', '${r.montant}', '${r.methode}')" style="padding: 0.3rem 0.6rem; font-size: 0.78rem;">
        <i class="ri-eye-line"></i> Voir Attestation
      </button>
    </li>
  `).join('');
}

function setupModals() {
  document.getElementById("btnPayRentNow")?.addEventListener("click", () => openPaymentModal(INITIAL_PROPERTIES[0]));
  document.getElementById("closePayModal")?.addEventListener("click", () => closeModal("paymentModal"));
  document.getElementById("quickAddPropertyBtn")?.addEventListener("click", () => openModal("addPropertyModal"));
  document.getElementById("openAddModalBtn")?.addEventListener("click", () => openModal("addPropertyModal"));
  document.getElementById("closeAddModal")?.addEventListener("click", () => closeModal("addPropertyModal"));

  const formAddProp = document.getElementById("addPropertyForm");
  const opSelect = document.getElementById("propOperation");
  const lblPrice = document.getElementById("lblPropPrice");
  const grpCaution = document.getElementById("grpCaution");

  opSelect?.addEventListener("change", (e) => {
    if (e.target.value === "Vente") {
      lblPrice.textContent = "Prix de vente total (FCFA)";
      if (grpCaution) grpCaution.style.display = "none";
    } else {
      lblPrice.textContent = "Loyer mensuel (FCFA)";
      if (grpCaution) grpCaution.style.display = "block";
    }
  });

  formAddProp?.addEventListener("submit", (e) => {
    e.preventDefault();
    const title = document.getElementById("propTitle").value;
    const operation = document.getElementById("propOperation").value;
    const sellerType = document.getElementById("propSellerType").value;
    const city = document.getElementById("propCity").value;
    const type = document.getElementById("propType").value;
    const price = parseInt(document.getElementById("propPrice").value);
    const desc = document.getElementById("propDesc").value;

    const newProp = {
      id: `prop-${Date.now()}`,
      title,
      city,
      type,
      operation,
      sellerType,
      price,
      cautionMois: operation === "Vente" ? 0 : 2,
      edan: true,
      seeg: true,
      gardien: true,
      titreFoncier: operation === "Vente",
      image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&w=600&q=80",
      description: desc || "Offre conforme aux normes gabonaises.",
      verified: true,
      bailleur: sellerType === "Agence Pro" ? "Votre Agence Immobilière Pro" : "Vous (Particulier)"
    };

    state.properties.unshift(newProp);
    renderProperties(state.properties);
    closeModal("addPropertyModal");
    alert(`L'annonce de ${operation} "${title}" a été publiée avec succès !`);
  });

  document.getElementById("closeReceiptModal")?.addEventListener("click", () => closeModal("receiptModal"));
}

function openModal(id) { document.getElementById(id)?.classList.remove("hidden"); }
function closeModal(id) { document.getElementById(id)?.classList.add("hidden"); }

function escapeHtml(str) {
  return str.replace(/[&<>"']/g, function(m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
  });
}
